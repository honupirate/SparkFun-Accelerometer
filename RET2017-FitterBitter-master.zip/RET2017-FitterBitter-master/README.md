"RET 2017 Fitter Bitter" 

Multiple files to write, program, output and collect data from the 
MPU 6050 sensor, Arduino Uno, Raspberry Pi, and Processing.  The 
goal of which is to create an educational activity tracker that can 
be used to teach the basics of accelerometers, gyros and other
activity tracker technology in a High School level computer science 
classroom.

By Nikki Schafer, James Laville, and Dr. Harvey Siy
